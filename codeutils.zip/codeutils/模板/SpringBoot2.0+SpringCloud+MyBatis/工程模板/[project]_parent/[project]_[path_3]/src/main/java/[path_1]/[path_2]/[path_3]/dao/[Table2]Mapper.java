package [package].dao;

import [package].pojo.[Table2];
import tk.mybatis.mapper.common.Mapper;

public interface [Table2]Mapper extends Mapper<[Table2]> {


}
