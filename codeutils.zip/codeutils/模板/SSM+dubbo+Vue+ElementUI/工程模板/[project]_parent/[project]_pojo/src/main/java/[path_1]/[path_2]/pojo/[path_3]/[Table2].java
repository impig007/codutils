package [path_1].[path_2].pojo.[path_3];
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
/**
 * [comment]实体类
 * @author Administrator
 *
 */
@Table(name="[table]")
public class [Table2] implements Serializable{

<实体类私有属性.key.txt>
	
<实体类私有属性.nokey.txt>
	
<实体类公有方法.txt>
	
}
