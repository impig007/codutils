package [package].pojo;

/**
 * [comment]实体类
 * @author [author]
 *
 */
@Table(name="[table]")
@Data
public class [Table2] implements Serializable{

<实体类私有属性.key.txt>

<实体类私有属性.nokey.txt>


}
