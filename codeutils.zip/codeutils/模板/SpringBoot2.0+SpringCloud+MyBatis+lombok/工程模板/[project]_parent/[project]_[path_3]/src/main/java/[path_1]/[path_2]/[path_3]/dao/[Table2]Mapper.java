package [package].dao;
        [package].pojo.[Table2];

public interface [Table2]Mapper extends Mapper<[Table2]> {


}
